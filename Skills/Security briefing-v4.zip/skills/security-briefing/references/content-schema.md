# content.json format

`scripts/build_briefing.py` reads one JSON file and renders the PDF. `assets/example-signdrop.json` is a complete example; copy it and replace the content.

## Top level

```json
{
  "title": "Document title (large, top of page 1, under the logo)",
  "short_title": "Shorter title used in the footer of every page",
  "subtitle": "Cybersecurity Risk Assessment and Security Briefing",
  "meta": [["Prepared for:", "..."], ["Date:", "..."], ["Prepared by:", "..."],
           ["Version:", "1.0"], ["Classification:", "Internal Use Only"], ["Status:", "..."]],
  "identification": [["Subject", "..."], ["Researcher", "..."], ["CVE and patch", "..."]],
  "bottom_line": ["**Bottom line**", "**Inherent risk:** High | ...", "**Recommendation:** ..."],
  "sections": [ { "heading": "1. Executive Summary", "blocks": [ ... ] } ]
}
```

- `meta` pairs are laid out two per row. The `Classification` and `Version` values also feed the page footer.
- `identification` is a two-column key/value table: the facts a reader wants before anything else.
- `bottom_line` is a list of paragraphs shown in the shaded callout. The first is the "Bottom line" label.
- `sections` includes the numbered sections and the appendices. Write the number or "Appendix A:" into `heading` yourself.
- The OCDE logo is added automatically. There is no field for it, by design.

## Text markup

Every text field accepts `**bold**` and `` `code` `` (monospace, for file names, registry paths, commands). Plain `&`, `<` and `>` are safe. In JSON, write a backslash as `\\` and a quote as `\"`.

## Block types

Each section's `blocks` is a list of objects with a `type`:

| type | Fields | Use |
|---|---|---|
| `p` | `text` | Paragraph |
| `h2` | `text` | Sub-heading inside a section |
| `bullets` | `items` (list of strings) | Parallel items |
| `note` | `text` | Small grey note under a heading or table |
| `table` | `columns`, `rows`, optional `widths`, `rating_col`, `bold_first`, `header` | Any table |
| `finding` | `id`, `severity`, `name`, `says`, `matters`, `treatment`, optional `analysis` | A three-part finding (fourth part optional) |

### Tables

- `columns`: header labels. Omit with `"header": false` for a key/value table.
- `widths`: relative column widths in inches. They are scaled to fit the 6.9 inch text width, so they need not sum exactly. Make narrow ID or status columns wide enough for their header word; a header that wraps mid-word looks broken.
- `rating_col`: zero-based index of a column to shade by its value. Recognized starting words: Critical, High, Moderate, Medium, Low, Effective, Met, Partial, Partially Met, Gap, Not Met, Not Evidenced, Unable, Insufficient, Unconfirmed, Triggered, Not triggered, Conflict, N/A, Required.
- `bold_first`: bold the first column (labels).
- Header rows repeat automatically when a table breaks across pages.

### Findings

`severity` shades the finding's header cell using the same words as `rating_col`. `treatment` should name condition IDs (for example "D1 to D5; M1") so every finding has a route to closure.

## Dates

The build prints every date it finds in the content. Confirm each is either the briefing date or stated in a source or by the user. Anything else must be replaced with relative timing or "TBD, to be set by [owner]".
