# Rating methodology

This is the GRC third-party risk method adapted to security events (vulnerabilities, exploits, breaches, campaigns, advisories). It keeps the parts that make an assessment defensible: evidence discipline, four control ratings, an assurance level, residual risk, escalation triggers, and conditions split by who controls them.

## Evidence discipline

- Every rating cites a source. No source, no rating: use **Not Evidenced**.
- A statement on a vendor's website or in a press quote is a **claim**. Independent testing, an audit report, or an advisory with technical detail is an **attestation**. Say which you have.
- Conflicts between sources are findings in their own right. Contradictions inside one source count too.
- Opened-in-full sources and search-excerpt sources are listed separately in the Sources appendix.

## Inherent risk

Set by four things together: impact if exploited, exposure conditions (what must already be true), exploit availability, and patch status.

| Level | Typical profile |
|---|---|
| Critical | Remote or self-propagating, public exploit or active exploitation, no fix |
| High | Public exploit, no fix, but needs a precondition such as local access |
| Moderate | Fix available but not yet deployed, or exploit not public |
| Low | Fixed and deployed, or no OCDE exposure |

For a breach or vendor incident, replace "exploit availability" with what data was exposed and whether OCDE data is in scope. Use the data tiers where student data is involved: DS4 (SSNs, health, IEP/504, mental health, biometrics, credentials, SIS write access), DS3 (identifiable student records, staff PII), DS2 (directory or pseudonymized data), DS1 (no PII). Education agencies hold student records on staff endpoints and servers, so state the population impact in plain words, but do not change the rating on that basis alone.

## Control ratings

Rate controls that bear on this specific event, not a generic checklist.

| Rating | Meaning |
|---|---|
| Effective | Documented and adequate for the inherent risk |
| Partial | Documented but with a material limitation |
| Gap | Documented and inadequate, or affirmatively bad |
| Not Evidenced | The sources and the requester say nothing; this is a finding, not a failure |

OCDE-side controls (inventory, telemetry retention, incident response, access limits) are Not Evidenced unless the requester supplied data. Map each row to NIST CSF 2.0 and CIS Controls v8 where it fits.

## Control Assurance Level

- **Strong**: no Gaps, at most 2 Not Evidenced, current independent evidence.
- **Adequate**: no Gaps in high-weight controls, at most 4 Not Evidenced.
- **Weak**: one or more Gaps, or 5 to 7 Not Evidenced.
- **Insufficient Evidence**: 8 or more Not Evidenced, or no evidence for remediation and for OCDE detection and response together. When this fires, say why in one line.

## Residual risk

| Assurance | Adjustment |
|---|---|
| Strong | Reduce inherent risk two levels (floor: Low) |
| Adequate | Reduce one level |
| Weak | No reduction |
| Insufficient Evidence | No reduction; write "Unable to Assess, treat as [inherent level]" |

## Escalation triggers

Use these in place of vendor hard stops. Give each a status and say what would change it. Statuses: **Triggered** (evidence establishes it), **Partially**, **Unconfirmed** (sources are silent; becomes a follow-up question, not a conclusion), **Not triggered**.

Typical triggers: confirmed exploitation in the wild; listing in CISA's Known Exploited Vulnerabilities catalog; vendor advisory, CVE or fix issued; indicators found on OCDE systems; reliable exploitation shown on OCDE's own builds; student data confirmed in scope; vendor withdraws or contradicts an earlier statement.

## Recommendation

| Residual | Recommendation |
|---|---|
| Low | Monitor; reassess on change |
| Moderate | Implement conditions; reassess on vendor response |
| High | Implement conditions now; escalate to CIO or CISO if any trigger fires |
| Critical | Escalate immediately with a compensating-control plan |
| Unable to Assess | Issue the follow-up questions; treat as the inherent level meanwhile |

State which of the two condition sets is load-bearing, and the fallback if the counterparty does not respond.

## Conditions, split by who controls them

1. **Conditions requiring the counterparty's action** (vendor fix, advisory, interim guidance). OCDE can track these but not enforce them.
2. **Conditions within OCDE's control** (inventory, configuration baseline, detections, telemetry retention, application control, access limits, expedited patching, monitoring, incident playbook). These are the floor: they apply however the counterparty responds.

Every condition needs an ID, the finding it addresses, a priority, an owner, a due value, and a verification artifact. "Improve security posture" is not a condition. The due value is relative to a real event ("before the fix is released") or "TBD, to be set by [owner]"; never a calendar date you chose.

## Findings

Severity-ranked and numbered. Each has three labeled parts: what the sources say, why it matters to OCDE, recommended treatment (referencing condition IDs). Cross-reference findings and conditions in both directions. When one finding rests on analysis a reader would otherwise challenge, such as a vendor claim that looks reassuring but is untested, give it a fourth part, "Analysis". One such finding per briefing at most.

## Regulatory considerations

Include only what applies. FERPA's school-official exception needs real direct control of records; a compromise that exposes education records can become an unauthorized disclosure. For state law (California by default unless the requester says otherwise), check that a statute's covered-data definition actually reaches the data involved before crediting it. Where applicability is genuinely uncertain, say so, and make a written legal determination a condition with an owner. Do not resolve it silently in either direction.
