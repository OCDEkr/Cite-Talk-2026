#!/usr/bin/env python3
"""Render an OCDE security briefing PDF from a content JSON file.

Usage:
    python3 build_briefing.py content.json output.pdf

The OCDE logo (../assets/ocde-logo.png) is placed at the top of page 1 and in the
running header of every later page. It is not optional: every briefing carries it.
The JSON format is documented in ../references/content-schema.md.

Text fields accept light markup: **bold** and `code`. Plain & < > are safe.
"""
import json
import os
import re
import sys

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import (BaseDocTemplate, Frame, Image, KeepTogether,
                                NextPageTemplate, PageTemplate, Paragraph, Spacer,
                                Table, TableStyle)

HERE = os.path.dirname(os.path.abspath(__file__))
LOGO = os.path.normpath(os.path.join(HERE, "..", "assets", "ocde-logo.png"))
LOGO_ASPECT = 369.0 / 2000.0  # height / width of the supplied logo
ORG = "Orange County Department of Education"

NAVY = colors.HexColor("#1F3A5F")
LIGHT = colors.HexColor("#EEF2F7")
ZEBRA = colors.HexColor("#F6F8FB")
GRID = colors.HexColor("#C5CEDA")
RED = colors.HexColor("#F4B6B6")
ORANGE = colors.HexColor("#F9CFA8")
AMBER = colors.HexColor("#FBE7A6")
GREEN = colors.HexColor("#C9E7C5")
GREY = colors.HexColor("#DADDE2")
RATING = {
    "critical": RED, "high": ORANGE, "moderate": AMBER, "medium": AMBER, "low": GREEN,
    "effective": GREEN, "met": GREEN, "partial": AMBER, "partially met": AMBER,
    "gap": RED, "not met": RED, "not evidenced": GREY, "unable": GREY,
    "insufficient": GREY, "unconfirmed": GREY, "not triggered": GREEN,
    "triggered": RED, "conflict": ORANGE, "n/a": colors.HexColor("#E7EAEE"),
    "required": colors.white,
}

W = 6.9 * inch  # usable width on letter with 0.8in side margins

base = ParagraphStyle("base", fontName="Helvetica", fontSize=9.4, leading=13, spaceAfter=5)
h1 = ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=14.5, leading=18,
                    textColor=NAVY, spaceBefore=10, spaceAfter=4, keepWithNext=1)
h2 = ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=10.8, leading=14,
                    textColor=NAVY, spaceBefore=7, spaceAfter=3, keepWithNext=1)
title_st = ParagraphStyle("title", fontName="Helvetica-Bold", fontSize=20, leading=24,
                          textColor=NAVY, spaceAfter=4)
subtitle_st = ParagraphStyle("subtitle", fontName="Helvetica", fontSize=10.5, leading=14,
                             textColor=colors.HexColor("#555555"), spaceAfter=10)
cell = ParagraphStyle("cell", fontName="Helvetica", fontSize=8.2, leading=10.6)
cellb = ParagraphStyle("cellb", parent=cell, fontName="Helvetica-Bold")
head = ParagraphStyle("head", parent=cell, fontName="Helvetica-Bold", textColor=colors.white)
bul = ParagraphStyle("bul", parent=base, leftIndent=14, bulletIndent=3, spaceAfter=3)
small = ParagraphStyle("small", parent=base, fontSize=8, leading=10.5,
                       textColor=colors.HexColor("#555555"), keepWithNext=1)
call = ParagraphStyle("call", parent=base, spaceAfter=3)


def md(text):
    """Escape XML characters, then apply **bold** and `code` markup."""
    t = str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"`(.+?)`", r'<font face="Courier" size="8">\1</font>', t)
    return t


def rating_color(text):
    low = str(text).lower()
    for key in sorted(RATING, key=len, reverse=True):
        if low.startswith(key):
            return RATING[key]
    return None


def logo_flowable(width_in):
    return Image(LOGO, width=width_in * inch, height=width_in * inch * LOGO_ASPECT,
                 hAlign="LEFT")


def make_table(columns, rows, widths=None, rating_col=None, bold_first=False, header=True):
    ncols = len(columns) if columns else len(rows[0])
    if widths:
        scale = 6.9 / float(sum(widths))
        col_w = [w * scale * inch for w in widths]
    else:
        col_w = [W / ncols] * ncols
    data = []
    if header and columns:
        data.append([Paragraph(md(c), head) for c in columns])
    for r in rows:
        line = []
        for j, c in enumerate(r):
            style = cellb if (bold_first and j == 0) else cell
            line.append(Paragraph(md(c), style))
        data.append(line)
    t = Table(data, colWidths=col_w, repeatRows=1 if (header and columns) else 0)
    style = [
        ("GRID", (0, 0), (-1, -1), 0.5, GRID),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 3.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
    ]
    first = 0
    if header and columns:
        style.append(("BACKGROUND", (0, 0), (-1, 0), NAVY))
        first = 1
    if header and columns:
        for i in range(first, len(data)):
            if i % 2 == 0:
                style.append(("BACKGROUND", (0, i), (-1, i), ZEBRA))
    if rating_col is not None:
        for i, r in enumerate(rows):
            col = rating_color(r[rating_col])
            if col is not None:
                style.append(("BACKGROUND", (rating_col, i + first), (rating_col, i + first), col))
    t.setStyle(TableStyle(style))
    return t


def callout(lines):
    paras = [Paragraph(md(l), call) for l in lines]
    t = Table([[paras]], colWidths=[W])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
        ("BOX", (0, 0), (-1, -1), 1, NAVY),
        ("LINEBEFORE", (0, 0), (0, -1), 4, NAVY),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return t


def finding(b):
    sev = b.get("severity", "")
    top = Table([[Paragraph("<b>%s</b>" % md(b["id"]), cellb),
                  Paragraph("<b>%s</b>" % md(b["name"]), cellb),
                  Paragraph("<b>%s</b>" % md(sev), cellb)]],
                colWidths=[0.55 * inch, 5.15 * inch, 1.2 * inch])
    top.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (1, 0), LIGHT),
        ("BACKGROUND", (2, 0), (2, 0), rating_color(sev) or LIGHT),
        ("BOX", (0, 0), (-1, -1), 0.5, GRID),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, GRID),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    rows = [["What the sources say", b["says"]],
            ["Why it matters to OCDE", b["matters"]]]
    if b.get("analysis"):
        rows.append(["Analysis", b["analysis"]])
    rows.append(["Recommended treatment", b["treatment"]])
    body = make_table(None, rows, widths=[1.55, 5.35], bold_first=True, header=False)
    return KeepTogether([top, body, Spacer(1, 9)])


def render_block(b):
    kind = b.get("type", "p")
    if kind == "p":
        return [Paragraph(md(b["text"]), base)]
    if kind == "h2":
        return [Paragraph(md(b["text"]), h2)]
    if kind == "note":
        return [Paragraph(md(b["text"]), small)]
    if kind == "bullets":
        return [Paragraph(md(i), bul, bulletText="•") for i in b["items"]]
    if kind == "table":
        return [make_table(b.get("columns"), b["rows"], b.get("widths"), b.get("rating_col"),
                           b.get("bold_first", False), b.get("header", True)), Spacer(1, 6)]
    if kind == "finding":
        return [finding(b)]
    raise ValueError("Unknown block type: %r" % kind)


def find_dates(obj, found):
    month = (r"(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|"
             r"Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)")
    pats = [re.compile(month + r"\.? \d{1,2}(?!\d)(?:, \d{4})?"),
            re.compile(month + r" \d{4}"),
            re.compile(r"\b\d{4}-\d{2}-\d{2}\b")]
    if isinstance(obj, str):
        for p in pats:
            for m in p.finditer(obj):
                found.add(m.group(0))
    elif isinstance(obj, dict):
        for v in obj.values():
            find_dates(v, found)
    elif isinstance(obj, list):
        for v in obj:
            find_dates(v, found)


def main():
    if len(sys.argv) != 3:
        sys.exit("Usage: build_briefing.py content.json output.pdf")
    src, out = sys.argv[1], sys.argv[2]
    if not os.path.exists(LOGO):
        sys.exit("Logo missing at %s. Every briefing must carry the OCDE logo." % LOGO)
    with open(src, encoding="utf-8") as fh:
        spec = json.load(fh)
    for key in ("title", "sections"):
        if key not in spec:
            sys.exit("content.json is missing required key: %s" % key)

    meta = spec.get("meta", [])
    meta_map = {k.lower().rstrip(": ").strip(): v for k, v in meta}
    classification = meta_map.get("classification", "Internal Use Only")
    version = meta_map.get("version", "1.0")
    short_title = spec.get("short_title", spec["title"])

    def footer(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 7.5)
        canvas.setFillColor(colors.HexColor("#666666"))
        canvas.drawString(0.8 * inch, 0.5 * inch,
                          "%s  |  %s  |  %s  |  v%s" % (ORG, classification, short_title, version))
        canvas.drawRightString(letter[0] - 0.8 * inch, 0.5 * inch, "Page %d" % doc.page)
        canvas.setStrokeColor(GRID)
        canvas.line(0.8 * inch, 0.65 * inch, letter[0] - 0.8 * inch, 0.65 * inch)
        canvas.restoreState()

    def later_pages(canvas, doc):
        # Running header: small logo on every page after the first.
        canvas.saveState()
        w = 1.6 * inch
        # Logo sits above the rule with clear space between them; the rule never crosses it.
        canvas.drawImage(LOGO, 0.8 * inch, letter[1] - 0.45 * inch - w * LOGO_ASPECT,
                         width=w, height=w * LOGO_ASPECT, mask="auto")
        canvas.setStrokeColor(GRID)
        canvas.line(0.8 * inch, letter[1] - 0.85 * inch, letter[0] - 0.8 * inch,
                    letter[1] - 0.85 * inch)
        canvas.restoreState()
        footer(canvas, doc)

    doc = BaseDocTemplate(out, pagesize=letter, leftMargin=0.8 * inch, rightMargin=0.8 * inch,
                          topMargin=0.6 * inch, bottomMargin=0.85 * inch,
                          title=spec["title"], author=ORG,
                          subject=spec.get("subtitle", "Security briefing"))
    fw, left, bottom = doc.width, doc.leftMargin, doc.bottomMargin
    doc.addPageTemplates([
        PageTemplate(id="first", frames=[Frame(left, bottom, fw, letter[1] - bottom - 0.6 * inch,
                                               id="f1")], onPage=footer),
        PageTemplate(id="later", frames=[Frame(left, bottom, fw, letter[1] - bottom - 0.95 * inch,
                                               id="f2")], onPage=later_pages),
    ])

    story = [NextPageTemplate("later"), logo_flowable(3.4), Spacer(1, 12)]
    story.append(Paragraph(md(spec["title"]), title_st))
    if spec.get("subtitle"):
        story.append(Paragraph(md(spec["subtitle"]), subtitle_st))

    if meta:
        rows = []
        for i in range(0, len(meta), 2):
            pair = meta[i:i + 2]
            row = []
            for k, v in pair:
                row += [k, v]
            while len(row) < 4:
                row += ["", ""]
            rows.append(row)
        story.append(make_table(None, rows, widths=[1.1, 2.55, 0.9, 2.35], header=False))
        story.append(Spacer(1, 8))
    if spec.get("identification"):
        story.append(make_table(None, spec["identification"], widths=[1.5, 5.4],
                                bold_first=True, header=False))
        story.append(Spacer(1, 9))
    if spec.get("bottom_line"):
        story.append(callout(spec["bottom_line"]))

    for sec in spec["sections"]:
        story.append(Paragraph(md(sec["heading"]), h1))
        for b in sec["blocks"]:
            story.extend(render_block(b))

    doc.build(story)

    dates = set()
    find_dates(spec, dates)
    print("Built %s" % out)
    if dates:
        print("Dates in this briefing (confirm each is stated in a source or is the assessment date):")
        for d in sorted(dates):
            print("  - %s" % d)


if __name__ == "__main__":
    main()
